This package contains the binary A121 Exploration Server for XM125.

Please see "Exploration Tool" under https://docs.acconeer.com/ in order to get started.

For more documentation please visit https://developer.acconeer.com

To view release notes use the following link: https://developer.acconeer.com/a121-sw-release-notes/
